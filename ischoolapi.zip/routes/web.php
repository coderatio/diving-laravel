<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('test/add-fee', 'TestingController@addFeeForm')->name('test.add.fee-form');
Route::post('test/add-fee', 'TestingController@storeFee')->name('test.add.fee');

Route::prefix('v1')->group(function() {
    // Validations
    Route::post('validatePaycode', 'VersionsController@validatePaycode')->name('api.validate.paycode');

    // Demo page
    Route::get('demo', 'VersionsController@index')->name('api.demo');

    // Fees
    Route::post('fees/add', 'FeesController@add')->name('fees.add');
    Route::post('fees/update', 'FeesController@update')->name('fees.update');
    Route::post('fees/delete', 'FeesController@delete')->name('fees.delete');
});
